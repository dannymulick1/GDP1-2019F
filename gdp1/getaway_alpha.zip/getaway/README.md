# GDPR1-getaway

This is the package that will house my GDP1 semester project, Getaway! The game consists of a player that controls a car, and walls that player must avoid.